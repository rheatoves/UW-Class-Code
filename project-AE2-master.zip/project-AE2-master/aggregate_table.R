
library(dplyr)
library(lintr)

wa_cases <- read.csv("./data/The_Covid_Tracking_Project.csv", stringsAsFactors = FALSE)

# this function returns a table with the total cases every 4 days.
# when looking at the graph, 
table <- function(dataframe) {
  
    Cases_Total_Mean <- mean(dataframe$Cases_Total, na.rm = T)
    Deaths_Total_Mean <- mean(dataframe$Deaths_Total, na.rm = T)
    Hospitalizations_Total_Mean <- mean(dataframe$Hospitalizations_Total, na.rm = T)
    df <- data.frame(Cases_Total_Mean, Deaths_Total_Mean, Hospitalizations_Total_Mean)
   
    
     return(df)
  
  
  
}



three_means <- table(wa_cases)

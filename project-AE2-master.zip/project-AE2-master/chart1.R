library(lintr)
library(styler)
library(ggplot2)

# Project AE2, summary information

# Load Data

wa_cases <- read.csv("./data/The_Covid_Tracking_Project.csv",
                     stringsAsFactors = FALSE)

# Scatter Plot

plot_data <- wa_cases %>%
  select(Date, Cases_Total)
  
  
 # select(Date, Cases_Total) %>%
 # mutate(date = as.Date(Date, format = "%Y%m%d")) %>%
 # filter(format(date, format = "%Y") == "2021") %>%
 # group_by("2021" = format(date, format = "%m%d")) %>%
 # summarise("cases" = (cases_total = sum(Cases_Total)))

plot <- ggplot(data = plot_data) +
  ggtitle("Cases Per Date") +
  geom_point(mapping = aes(x = Cases_Total, y = Date))

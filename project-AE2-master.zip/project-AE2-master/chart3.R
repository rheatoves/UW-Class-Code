library(lintr)
library(ggplot2)
library(leaflet)
library(plotly)

CTP_df <- read.csv("./data/The_Covid_Tracking_Project.csv",
                   stringsAsFactors = FALSE)
  Cases_White <- CTP_df$Cases_White
  Cases_Total <- CTP_df$Cases_Total
  cases_data_df <- data.frame(Cases_White, Cases_Total)
 
chart_three <- ggplot(data = cases_data_df) +
    ggtitle("How Has the Number of White Cases Changed in Relation to
            Total Cases") +
    geom_col(mapping = aes(x = Cases_White, y = Cases_Total, fill = "Cases"))

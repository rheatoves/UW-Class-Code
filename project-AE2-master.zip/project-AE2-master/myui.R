ui <- navbarPage(theme = shinytheme("cerulean"),
  title = "The Covid-19 Project",
  tabPanel("Overview",
           h3("Analyizing The COVID Tracking Project Dataset"),
           tags$p("The COVID Tracking Project tracks how COVID-19 has
           disproportionately affected Black, Indegenous, Latinx, and other
           people of color. As COVID-19 has greatly affected these communities,
           this project aims to follow and cross-check data all around the
           United States with emphasis on testing, hospitalization, patient
           outcomes, racial and ethnic demographic information. The purpose of
           our analysis is to develop critical thinking and examine data
           provided by 'The COVID Tracking Project' and how the virus affected
                  various demographics."),
           br(),
           h3("The Source of Data"),
           tags$p("The COVID Tracking Project is a collaborative volunteer-run
                  effort to track the ongoing COVID-19 pandemic in the United
                  States. This data was gathered from the 'Census Bureau's 2019
                  ACS 5-Year estimates'. There's multiple datasets provided by
                  this website (based on each state) with several observations
                  and features. We specifically chose the dataset from based
                  on results from Washington State."),
           br(),
           h3("Goals of the Project"),
           tags$p("During our analysis, we looked to answer these three
                  questions:"),
           tags$ol(
           tags$li("What were the statistics of the number of cases,
                   deaths, and hospitalizations in Washington during 2020
                   and 2021?"),
           tags$li("How were different POC communities affected by
           COIVD-19 in comparison to Caucasian people?"),
           tags$li("In the year of 2020 how did groups of Asian, Black,
           AIAN, NHPI, Latinx, and Hispanic, (POC) etc. vary with total
                   cases?")
      )
      ),
      tabPanel(("Overall Statistics"),
      h3("Number of Cases, Deaths, and Hospitalizations Per Year"),
      tags$p("The purpose of this bar chart is to compare the totals of cases,
             deaths, and hospitalizations per year (2020 and 2021). You are able
             to select data based on the years below."),
      br(),
      sidebarPanel(
        selectInput("year", "Choose a Year",
                    choices= c("2020" = "2020",
                               "2021" = "2021"))
      ),
      mainPanel(
        plotOutput(
        outputId = "secondbargraph"))
      ),
      tabPanel(("Comparing Demographics"),
      h3("POC Groups vs. White Total Cases"),
      tags$p("The purpose of this bar chart is to compare different POC
             Demographics total COVID-19 cases side-by-side with the total
             White cases. Below you are able to select different POC
             Demographics in order to compare different total cases with the
             Caucasian group."),
      br(),
      sidebarPanel(
        selectInput("poc", "Choose a POC Demographic",
                    choices= c("Asian" = colnames(date_df)[3],
                                "Black" = colnames(date_df)[5],
                                "AIAN" = colnames(date_df)[4],
                                "LatinX" = colnames(date_df)[10],
                                "NHPI" = colnames(date_df)[8],
                                "Multiracial" = colnames(date_df)[9],
                                "Other" = colnames(date_df)[7]))
      ),
      mainPanel(
        plotOutput(
          outputId = "bargraph"))
      ),
      tabPanel(("Cases in 2020"),
      h3("Comparing Total Cases in 2020"),
      tags$p("The purpose of this scatter plot graph is to show and compare the
             total cases per ethnicity in the year 2020. Below you are able to
             select the each ethnicity group to view the total cases throughout
             the year 2020."),
      br(),
      sidebarPanel(
        selectInput("demographic", "Choose a Demographic",
                    choices= c("Asian" = colnames(date_df)[3],
                               "Black" = colnames(date_df)[5],
                               "AIAN" = colnames(date_df)[4],
                               "LatinX" = colnames(date_df)[10],
                               "White" = colnames(date_df)[6],
                               "NHPI" = colnames(date_df)[8],
                               "Multiracial" = colnames(date_df)[9],
                               "Other" = colnames(date_df)[7]))
      ),
      mainPanel(
        plotOutput(
          outputId = "demoplot"))
      ),
      tabPanel("Summary Takeaways", h3("Three Major Takeaways"),
               tags$p("COVID-19 took the lives of many Americans and others around
                  the world. enclosing our lens to just the state of Washington,
                  it is important to recognize that BIPOC communities are
                  affected at a higher percentage as they are most likely to be
                  left out in healthcare field.  COVID-19 does not discriminate,
                  but health care does. Covid-19 is an infectious diseases and
                  individuals who have caught it are mostly like asymptomatic.
                  With this, we can make a greater conclusion which is that
                  race, physical environment, income, and education has played
                  a big role on the affects of the COVID-19 pandemic in
                  Washington. Throughout this project, we were able to make
                  several other conclusions as well:"),
               h3("Project Goals and Conclusions"),
               tags$b("What were the statistics of the number of cases,
                      deaths, and hospitalizations in Washington during 2020
                      and 2021?"),
               tags$p("At the beginning of the pandemic, BIPOC communities
                       were not affected greatly, but as it continued to
                       heightened they began to become disproportionately
                       affected."),
               br(),
               tags$b("How were different POC communities affected by COIVD-19
                      in comparison to Caucasian people?"),
               tags$p("Racial and ethnic minorities are affected by the lack
                         of access to education which leads to lower literacy
                         levels and understanding the affects in this case of
                         COVID-19."),
               br(),
               tags$b("In the year of 2020 how did groups of Asian, Black, AIAN,
               NHPI, Latinx, and Hispanic, (POC) etc. vary with total cases?"),
               tags$p("Looking at the number of hospitalizations especially the
                       hospitalizations with racial communities, we can conclude
                       that one of these reasons can be due to the distrust of
                       the healthcare system. Another reason being the income
                       barriers which keeps them from being able to affordable
                       health insurance and medical bills."))
      )
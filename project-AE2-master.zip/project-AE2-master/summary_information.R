library(lintr)
library(styler)

# Project AE2, summary information

rm(list = ls())

# Load Data

wa_cases <- read.csv("./data/The_Covid_Tracking_Project.csv",
                     stringsAsFactors = FALSE)

# Summary Information Function

get_summary_info <- function(dataframe) {
  asian_mean <- mean(dataframe$Cases_Asian, na.rm = T)
  aian_mean <- mean(dataframe$Cases_AIAN, na.rm = T)
  black_mean <- mean(dataframe$Cases_Black, na.rm = T)
  white_mean <- mean(dataframe$Cases_White, na.rm = T)
  nhpi_mean <- mean(dataframe$Cases_NHPI, na.rm = T)
  other_mean <- mean(dataframe$Cases_Other, na.rm = T)
  list_of_means <- list("Asian_mean" = round(asian_mean, digits = 0),
                        AIAN_mean = round(aian_mean, digits = 0),
                        Black_mean = round(black_mean, digits = 0),
                        White_mean = round(white_mean, digits = 0),
                        NHPI_mean = round(nhpi_mean, digits = 0),
                        Other_mean = round(other_mean, digits = 0))
  return(list_of_means)
}

# Plugging in the Dataframe into Function

cases_mean <- get_summary_info(wa_cases)
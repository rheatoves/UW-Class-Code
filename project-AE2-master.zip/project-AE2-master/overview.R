library(ggplot2)
library(plotly)
library(dplyr)
library(shiny)

# UI Page

ui <- navbarPage(title = "The Covid-19 Project",
    tabPanel("overview", h1("The Covid-19 Project .R Data Anaylsis"),
             tags$img(src = "https://www.statnews.com/wp-content/uploads/2020/02
             /Coronavirus-CDC-1600x900.jpg", width = 1600, height = 900),
             hr(),
             br(),
             h2("A quick overview"),
             tags$p("The COVID Tracking Project tracks how COVID-19 has
                    disproportionately affected Black, Indegenous, Latinx,
                    and other people of color. As COVID-19 has greatly
                    affected these communities, this project aims to follow
                    and cross-check data all around the United States with
                    emphasis on testing, hospitalization, patient outcomes,
                    racial and ethnic demographic information. The purpose of
                    our anaylsis is to develop critical thinking and examination
                    of data provided by The COVID Tracking Project and how the
                    virus affected various demographics that we find 
                    important."),
             br(),
             h2("Our anaylsis"),
             tags$p("During our anaylsis, we looked to answer these three
                    questions:"),
             tags$ol(
               tags$li("Out of the number of cases in Washington, how many
                       deaths occured and how many people were hospitalized?"),
               tags$li("How were POC affected by COIVD-19 in comparison to
                       Caucasian people?"),
               tags$li("When comparing groups of Asian, Black, AIAN, NHPI,
                       Latinx, and Hispanic, (POC) etc. vary with total cases?")
             )
             ),
    taPanel("deaths total", "contents"),
    tabPanel("cases total", "contents"),
    tabPanel("hospitalizations total", "contents")
)

library("shiny")
library("dplyr")
library("ggplot2")
library("plotly")

# How were POC affected by COVID-19 in comparison to White people

data <- read.csv("project-AE2/The_Covid_Tracking_Project.csv", stringsAsFactors = FALSE)

# sum of cases for white, and sum for the average for all POC
white_cases <- sum(data$Cases_White)
colored_cases <- (sum(data$Cases_Asian) + sum(data$Cases_AIAN) + sum(data$Cases_Black) + 
                 sum(data$Cases_Other) + sum(data$Cases_NHPI) + sum(data$Cases_Multiracial) +
                 sum(data$Cases_LatinX)) / 7
df <- data.frame("ethnicity" = c("White", "Colored"), cases = c(white_cases, colored_cases))
  
 # graph of sum of cases for white and POC(where it is the overall average for all POC) 
  
  plot_gragh_2 <- ggplot(data = df, aes(x=ethnicity, y=cases, fill=ethnicity)) +
       ggtitle("Average sum of Cases For White and POC") +
       geom_bar(stat = "identity")

ggplotly(plot_gragh_2)
server <- function(input, output) {
  wa_cases <- read.csv("./data/The-Covid-Tracking-Project.csv",
                       stringsAsFactors = FALSE)
  
  output$demoplot <- renderPlot({
    date_df <- wa_cases %>%
      mutate(dates = as.Date(as.character(Date), format = "%Y%m%d")) %>%
      filter(format(dates, format = "%Y") == "2020") %>%
      mutate(Months = format(dates, format = "%m")) %>%
      mutate(Cases = date_df[ , input$demographic])
    
    plot_graph <- ggplot(data = date_df) +
      ggtitle("Total Cases Per Ethnicity in 2020") +
      geom_point(mapping = aes(x = Months, y = Cases))
    return(plot_graph)
  })
  output$bargraph <- renderPlot({
    white_cases <- sum(wa_cases$Cases_White)
    colored_cases <- (sum(wa_cases[ , input$poc]))
    df <- data.frame("Ethnicity" = c("White Group", "POC Group"),
                     Cases = c(white_cases, colored_cases))
    bar_graph <- ggplot(data = df, aes(x=Ethnicity, y=Cases, fill=Ethnicity)) +
      ggtitle("Average Sum of Cases For White and POC Groups") +
      geom_bar(stat = "identity")
    return(bar_graph)
  })
  output$secondbargraph <- renderPlot({
    new_date_df <- wa_cases %>%
      mutate(dates = as.Date(as.character(Date), format = "%Y%m%d")) %>%
      filter(format(dates, format = "%Y") == input$year) %>%
      mutate(Months = format(dates, format = "%m"))
    
    cases_sum <- sum(new_date_df$Cases_Total, na.rm = T)
    hospitalizations_sum <- sum(new_date_df$Hospitalizations_Total, na.rm = T)
    deaths_sum <- sum(new_date_df$Deaths_Total, na.rm = T)
    totals_df <- data.frame(
      Types <- c("Cases", "Deaths", "Hospitalizations"),
      Sum <- c(cases_sum, deaths_sum, hospitalizations_sum)
    )
    sum_plot <- ggplot(totals_df, aes(x = Types, y = Sum)) +
      ggtitle("Total Cases, Deaths, and Hospitalizations in Washington") +
      geom_bar(stat = "identity") +
      scale_fill_grey(start = 0.25, end = 0.75) +
      theme(legend.position="none")
    return(sum_plot)
  })
}

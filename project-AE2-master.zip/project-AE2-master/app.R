library("shiny")
library("ggplot2")
library("dplyr")
library("plotly")
library("shinythemes")

source("myui.R")
source("myserver.R")

shinyApp(ui = ui, server = server)

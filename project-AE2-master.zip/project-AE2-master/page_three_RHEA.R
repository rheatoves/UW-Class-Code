library(lintr)
library(styler)
library(dplyr)
library(ggplot2)

wa_cases <- read.csv("./data/The-Covid-Tracking-Project.csv",
                     stringsAsFactors = FALSE)

date_df <- wa_cases %>%
  mutate(dates = as.Date(as.character(Date), format = "%Y%m%d")) %>%
  filter(format(dates, format = "%Y") == "2020") %>%
  mutate(months = format(dates, format = "%m"))

plot_graph <- ggplot(data = date_df) +
  ggtitle("Total Cases Per Ethnicity") +
  geom_point(mapping = aes(x = months, y = Cases_LatinX))

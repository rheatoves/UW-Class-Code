library("Shiny")
library("ggplot2")
library("dplyr")
library("tidyr")
library("plotly")

#load data 
CTP_df <- read.csv("data/The Covid Tracking Project.csv",
                      stringsAsFactors = FALSE)
#chart 1
cases_sum <- sum(CTP_df$Cases_Total, na.rm = T)

hospitalizations_sum <- sum(CTP_df$Hospitalizations_Total, na.rm = T)

deaths_sum <- sum(CTP_df$Deaths_Total, na.rm = T)

totals_df <- data.frame(
  types <- c("cases", "deaths", "hospitalizations"),
  
  sum <- c(cases_sum, deaths_sum, hospitalizations_sum)
)

sum_plot <- ggplot(totals_df, aes(x = types, y = sum)) +
  ggtitle("Total Cases, Deaths, and Hospitalizations in Washington.") +
  geom_bar(stat = "identity") +
  scale_fill_grey(start = 0.25, end = 0.75) +
  theme(legend.position="none")

sum_plot

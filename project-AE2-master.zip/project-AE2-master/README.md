# Final Project
## Domain of interest - COVID 19
-----------------------------------
## Why are you interested in this field/domain?

* We are interested in this topic because not only is it a very relavant world issue right now but it has affected the lives of many people in the world. People in all corners of the world are immensely affected by Covid 19 and so it is important that we provide important data for the 'Corona Virus'.

## Examples of other data driven projects related to this domain.
* [The Covid Tracking Project](https://covidtracking.com/race/dashboard "The Covid Tracking Project")
  * The COVID Tracking Project is a collaborative volunteer-run effort to track the ongoing COVID-19 pandemic in the United States. This data was gathered from the "Census Bureau’s 2019 ACS 5-Year estimates". There's multiple datasets provided by this website (based on each state) with several observations and features.
* [Covid Exit Strategy](https://www.covidexitstrategy.org/ "Covid Exit Strategy")
  * The Covid Exit Strategy is non partison project including interal documents from the Department of Health and Human Services, Centers for Disease Control and Prevention, Office of the Assistant Secretary for Preparedness and Response, and the U.S. Digital Service. This is data from the federal government. The main dataset, "How is My State Doing on Key Measures" has 50 observations and 7 features.
 * [Covid Data Project](https://covid19dataproject.org/map-gallery/)
   * This brings us to a map gallery that goes into depth on the statistical data in every city in a chosen state. The maps are color coded to indicate the 'total confirmed cases and deaths' in each area. This data is collected from all states and cities reporting their cases and deaths. There's multiple datasets provided by this website (based on each state) with several observations and features.
* [The COVID-19 Impact on Amazon and Walmart Sales](https://feedvisor.com/resources/amazon-trends/the-covid-19-impact-on-amazon-and-walmart-sales/)
  * This website provides two separate sets of data. The first set is "Total Sales Changes by Category" and the second is, "Total Sales Changes for the Top 3 Categories". This data was gathered from customer sales data in Amazon and Walmart's marketplaces. The first data set has 5 features and 5 observations. The second data set has 3 observations and 3 features.
* [Mental Health Household Pulse Survey](https://www.cdc.gov/nchs/covid19/pulse/mental-health.htm)
  * This data set was gathered by the National Center for Health Statistics (NCHS) and the Census Bureau. NCHS included questions to obtain information on the frequency of anxiety and depression symptoms during these times. There were several data collection periods, during each phase of COVID-19. The results from the Household Pulse Survey show the percentage of adults who report symptoms of anxiety or depression. There are 28 features and 7 main observations.


 ## What data driven questions do you hope to answer about this domain?  
* How have certain industries benefited from the pandemic and what are the ethical implications of this.
  * The datasets from the website, "The COVID-19 Impact on Amazon and Walmart Sales" would help answer this question. Looking into big corporations like Amazon and Walmart.
* How have individuals' mental health been affected by the pandemic?
  * Data from the Household Pulse Survey results can help answer this question. Especially because this data set breaks down information under age, gender, state, race, etc.
* How were communities of color and lower socioeconomic communities impacted during the height of the covid-19 pandemic?
  * The first data set "The Covid Tracking Project" will be able to answer question. The data set focuses on individual races/ethnicities, the percentag of group cases and deaths.
* How were/are college students of a lower socioeconomic communities navigating college?
* What happened to the retention rate as college became virtual?

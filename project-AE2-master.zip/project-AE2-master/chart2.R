library(lintr)
library(ggplot2)
library(leaflet)
library(plotly)

deaths_per_ethnicity <- read.csv("./data/The_Covid_Tracking_Project.csv",
                              stringsAsFactors = FALSE)

deaths_AIAN_total <- sum(deaths_per_ethnicity$Deaths_AIAN)
deaths_Black_total <- sum(deaths_per_ethnicity$Deaths_Black)
deaths_white_total <- sum(deaths_per_ethnicity$Deaths_White, na.rm = T)
deaths_Hispanic_total <- sum(deaths_per_ethnicity$Deaths_Ethnicity_Hispanic, na.rm = T)
deaths_NonHispanic_total <- sum(deaths_per_ethnicity$Deaths_Ethnicity_NonHispanic, na.rm = T)
deaths_Unknown_total <- sum(deaths_per_ethnicity$Deaths_Ethnicity_Unknown, na.rm = T)
deaths_Latinx_total <- sum(deaths_per_ethnicity$Deaths_LatinX, na.rm = T)
deaths_multiracial_total <- sum(deaths_per_ethnicity$Deaths_Multiracial, na.rm = T)
deaths_NHPI_total <- sum(deaths_per_ethnicity$Deaths_NHPI, na.rm = T)
deaths_other_total <- sum(deaths_per_ethnicity$Deaths_Other, na.rm = T)
deaths_total <- sum(deaths_per_ethnicity$Deaths_Total, na.rm = T)

deaths_per_ethnicity_total <- data.frame (
  deaths_AIAN_total,
  deaths_Black_total,
  deaths_Hispanic_total,
  deaths_white_total,
  deaths_Latinx_total,
  deaths_NonHispanic_total,
  deaths_Unknown_total,
  deaths_other_total,
  deaths_multiracial_total,
  deaths_NHPI_total)

ethnicities_deaths <- c(4700, 6890, 27501, 27587, 2628, 3282, 3811, 4113, 150966)
ethnicities <- c ("AIAN", "Black", "Hispanic", "LatinX", "Multiracial", "NHPI", "Other", "unknown", "White")

deaths_per_ethnicity_totals <- data.frame(ethnicities, ethnicities_deaths, stringsAsFactors=FALSE)

pie <- ggplot(deaths_per_ethnicity_totals, aes("ethnicity deaths", y=ethnicities_deaths, fill=ethnicities)) +
  ggtitle("Deaths Per Ethnicity") +
  geom_bar(stat="identity", width=1) +
  coord_polar("y", start=0)
